from pathlib import Path
import subprocess,tempfile,shutil,json,hashlib,xml.etree.ElementTree as ET,time,os
E=Path(__file__).parent;W=Path('/Users/teacher/.codex/automations/pd-workloop-resume/worktrees/tpp-1658-receipts-20261010');PY=str(E/'tool-env/bin/python');H='src/travel_plan_permission/portal_receipt_store.py';R='src/travel_plan_permission/portal_receipts.py';T='tests/python/test_portal_receipt_api.py';sha=lambda b:hashlib.sha256(b).hexdigest()
cases=[
 ('accepted',H,'if draft.receipt_binding and response.submission_status in {','if False and response.submission_status in {','test_unaccepted_submission_cannot_create_request_or_review[unavailable]',['assert 200 == 503']),
 ('owner',H,'prior.owner_subject,','binding.owner_subject,','test_owner_is_identity_not_traveler_name_or_id',['AssertionError: foreign subject must not read the receipt']),
 ('snapshot',H,'prior.snapshot_sha256 != binding.snapshot_sha256','False','test_retries_snapshot_conflicts_and_same_trip_new_snapshot',['AssertionError: changed snapshot must conflict']),
 ('tenant',H,'prior.owner_namespace,','binding.owner_namespace,','test_oidc_signed_tokens_validate_issuer_audience_and_namespace',['AssertionError: tenant namespace must remain isolated']),
 ('retry',H,'if draft.receipt_binding and draft.submission_response and manager_review:','if False:','test_decision_is_not_reset_by_submission_retry[request_changes]',['AssertionError: retry must preserve the recorded decision']),
 ('truthful',R,'state: Literal["prepared", "submitted", "pending_review", "decision_recorded"] = (\n        "prepared"\n    )','state: Literal["prepared", "submitted", "pending_review", "decision_recorded"] = (\n        "submitted"\n    )','test_real_submission_manager_decision_and_restart',["assert 'submitted' == 'prepared'","AssertionError: assert 'submitted' == 'prepared'"])
]
original={p:(W/p).read_bytes() for p in [H,R,T]};out=E/'accepted-mutations';out.mkdir(exist_ok=False);receipt={'bindings':{p:sha(b) for p,b in original.items()},'cases':[]}
with tempfile.TemporaryDirectory(prefix='tpp-receipt-mutations-') as root:
 root=Path(root)
 for f in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=W).split(b'\0'):
  if f:
   p=Path(f.decode());target=root/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(W/p,target)
 env=os.environ.copy();env['PYTHONPATH']=str(root/'src')
 try:
  for label,path,before,after,name,expected in cases:
   data=original[path];assert data.decode().count(before)==1,(label,'anchor not unique');mutant=data.decode().replace(before,after,1).encode();c={'label':label,'path':path,'before':before,'after':after,'node':T+'::'+name,'intended_failure_messages':expected,'phases':[]};receipt['cases'].append(c)
   for phase,source,exitcode in [('red',mutant,1),('green',data,0)]:
    (root/path).write_bytes(source)
    for cache in (root/'src/travel_plan_permission').glob('**/__pycache__/*.pyc'):cache.unlink()
    stem=f'{label}-{phase}';xml=out/(stem+'.xml');argv=[PY,'-m','pytest',c['node'],'-q','--junitxml='+str(xml)];started=time.time()
    with (out/(stem+'.txt')).open('w') as stream:r=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
    nodes=ET.parse(xml).getroot().findall('.//testcase');valid=r.returncode==exitcode and len(nodes)==1 and nodes[0].get('name')==name and nodes[0].find('error') is None and nodes[0].find('skipped') is None
    failure=nodes[0].find('failure') if nodes else None;message=failure.get('message','').splitlines()[0] if failure is not None else None
    valid=valid and ((failure is not None and message in expected) if phase=='red' else failure is None)
    c['phases'].append({'phase':phase,'exit':r.returncode,'argv':argv,'cwd':str(root),'source_sha256':sha((root/path).read_bytes()),'seconds':time.time()-started,'failure_message':message,'valid':valid})
    if not valid:raise RuntimeError((label,phase,message,r.returncode))
   (root/path).write_bytes(data)
 finally:
  for p,b in original.items():(root/p).write_bytes(b)
  receipt['isolated_restored']={p:sha((root/p).read_bytes()) for p in original};receipt['caller_unchanged']=all((W/p).read_bytes()==b for p,b in original.items());(out/'controls.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('6 intended production mutation RED / exact-restoration GREEN pairs, caller unchanged')
